JD RETAILER - SUBSCRIPTION ONLY / NO TRIAL

SUBSCRIPTION MODEL
- No free trial.
- User enters phone number/account.
- App requires an active Google Play subscription before billing features open.
- Price shown: ₹50/month.
- Google Play product ID: monthly_50.
- Expired/cancelled subscription returns the user to the paywall.
- Restore Subscription is available.

PLAY STORE PAYMENT
For the Play Store build, subscription payment is handled through Google Play Billing.
Do not hard-code a personal UPI ID as the unlock mechanism for a Play-distributed digital subscription.
Google Play supports UPI as a payment method for users, including UPI AutoPay for recurring subscriptions,
but the payment is processed through Google Play.

OWNER UPI
The supplied UPI ID is intentionally NOT hard-coded into the Play Store subscription unlock flow.
If you later distribute a separate non-Play APK or enroll in Google's India alternative-billing programme,
that would require a separate compliant implementation and server-side payment verification.

OTHER FEATURES REMAIN
- JD Retailer branding
- Editable business profile per retailer
- Purchase Entry / Product Master
- Clean billing screen
- A5 portrait locked invoice
- PDF invoice generation
- PDF sharing to WhatsApp
- stock, invoice history, reports, profit/loss
- local phone storage + automatic backup
- ₹50/month subscription gate

BUILD
Build APK for local testing.
Generate signed AAB for Play Store release.
